# Week 6 Experiment Notes

## Experiment

The Python program measures the time required for naive polynomial multiplication modulo `x^n + 1`.

Tested dimensions:

- n = 8
- n = 16
- n = 32
- n = 64
- n = 128

The benchmark is intended to show a basic relationship between polynomial dimension and computation time.

## Expected observation

As `n` increases, the naive multiplication becomes slower because the implementation uses nested loops over the polynomial coefficients.

The educational implementation is approximately quadratic in the polynomial dimension:

`O(n^2)`

Modern lattice-based cryptographic implementations use optimized algorithms and carefully engineered arithmetic. In particular, practical schemes can use techniques such as NTT-based polynomial multiplication.

## Important limitation

The benchmark depends on the computer, Python version, operating system, and system load. Therefore, the measured microsecond values should not be treated as universal performance numbers.

For a research report, record the output from your own machine and state your hardware/software environment.
