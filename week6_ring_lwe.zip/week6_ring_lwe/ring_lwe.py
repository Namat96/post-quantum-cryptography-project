"""
Week 6 - Educational Ring-LWE implementation in Python.

WARNING:
This is a toy implementation for learning only.
It is NOT secure cryptography.
"""

import random

Q = 97
N = 8
ERROR_VALUES = (-1, 0, 1)


def reduce_mod_q(poly):
    """Reduce every coefficient modulo Q."""
    return [x % Q for x in poly]


def trim(poly):
    """Keep exactly N coefficients."""
    result = list(poly[:N])
    result += [0] * (N - len(result))
    return result


def add_poly(a, b):
    """Add two polynomials modulo Q."""
    return [
        (a[i] + b[i]) % Q
        for i in range(N)
    ]


def negacyclic_mul(a, b):
    """
    Multiply polynomials modulo:

        x^N + 1

    Therefore x^N = -1.

    If a term has degree >= N, it wraps around
    with a negative sign.
    """
    result = [0] * N

    for i in range(N):
        for j in range(N):
            degree = i + j
            value = a[i] * b[j]

            if degree < N:
                result[degree] += value
            else:
                result[degree - N] -= value

    return reduce_mod_q(result)


def random_polynomial():
    """Generate a random polynomial in Z_Q[x]."""
    return [
        random.randrange(Q)
        for _ in range(N)
    ]


def small_polynomial():
    """Generate a polynomial with small coefficients."""
    return [
        random.choice(ERROR_VALUES)
        for _ in range(N)
    ]


def generate_rlwe_instance():
    """
    Generate:

        b = a*s + e (mod q, x^N + 1)
    """
    a = random_polynomial()
    s = small_polynomial()
    e = small_polynomial()

    a_times_s = negacyclic_mul(a, s)
    b = add_poly(a_times_s, e)

    return a, s, e, b


def polynomial_string(poly):
    """Display a coefficient vector as a polynomial."""
    terms = []

    for i, coefficient in enumerate(poly):
        if coefficient == 0:
            continue

        if i == 0:
            terms.append(str(coefficient))
        elif i == 1:
            terms.append(f"{coefficient}x")
        else:
            terms.append(f"{coefficient}x^{i}")

    return " + ".join(terms) if terms else "0"


def main():
    print("=" * 60)
    print("Week 6 - Toy Ring-LWE in Python")
    print("=" * 60)

    print(f"\nParameters:")
    print(f"q = {Q}")
    print(f"N = {N}")
    print("Ring = Z_q[x] / (x^N + 1)")

    a, s, e, b = generate_rlwe_instance()

    print("\nPublic polynomial a:")
    print(polynomial_string(a))

    print("\nSecret polynomial s:")
    print(polynomial_string(s))

    print("\nError polynomial e:")
    print(polynomial_string(e))

    print("\nPublic value b = a*s + e:")
    print(polynomial_string(b))

    # Recalculate b independently.
    calculated = add_poly(
        negacyclic_mul(a, s),
        e
    )

    print("\nVerification:")
    print("b == a*s + e :", b == calculated)

    print("\nCoefficient representation:")
    print("a =", a)
    print("s =", s)
    print("e =", e)
    print("b =", b)

    print("\n" + "=" * 60)
    print("Ring-LWE demonstration complete.")
    print("=" * 60)


if __name__ == "__main__":
    main()
