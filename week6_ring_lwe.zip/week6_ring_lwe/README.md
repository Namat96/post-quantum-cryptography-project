# Week 6 — Ring-LWE Implementation in Python

## Overview

Week 6 moves from the SageMath experiments of Week 5 to a small educational **Ring-LWE (RLWE)** implementation in Python.

The purpose is to understand how polynomial arithmetic can represent structured lattice-based cryptographic operations.

> **Security warning:** This is a toy educational implementation. It is not a secure cryptographic scheme and must not be used for real-world encryption.

## Objectives

- Represent polynomials using coefficient lists.
- Implement addition modulo `q`.
- Implement multiplication modulo `x^n + 1`.
- Generate small secret and error polynomials.
- Generate a random public polynomial.
- Construct an RLWE-style public value:
  `b = a*s + e (mod q)`.
- Verify the relation.
- Compare the implementation conceptually with the SageMath version.

## Mathematical Model

The simplified RLWE relation used in this week is:

\[
b = a s + e \pmod{(q,\ x^n+1)}
\]

where:

- `a` is a public polynomial,
- `s` is a small secret polynomial,
- `e` is a small error polynomial,
- `q` is the modulus,
- arithmetic is performed modulo `x^n + 1`.

## Files

- `ring_lwe.py` — educational RLWE polynomial implementation.
- `README.md` — explanation and instructions.

## Run

```bash
python ring_lwe.py
```

The program prints the generated polynomials and verifies the RLWE relation.

## Important

The implementation is deliberately small and readable. It is designed to show the mathematics, not to reproduce a standardized post-quantum cryptographic scheme.
